# donation
Payment api integration in PHP website (to be submitted in Internship at Sparks Foundation).

### What:-
This is an instamojo payment api integration created with learning purpose only hosted on 000webhost.

### Tech:-
PHP and some MySQL commands, (basics of HTML, CSS)

### Hosting URL:-
https://problemshavesolution.000webhostapp.com/


### demo link:-
https://youtu.be/hm_uCO2zCtU
