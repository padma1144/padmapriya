# CreditManagementApp
CREDIT MANAGEMENT APP(THE SPARKS FOUNDATION INTERNSHIP)

I have developed this application using mysql as database and its structure is as in this screenshot.

![alt Table Structure](https://github.com/santosh-36/CreditManagementApp/blob/master/credit_management_table_structure.png)

If you face any problems regarding this project raise an issue.
