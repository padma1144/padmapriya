# Credit-Management-Website
Sparks Foundation Internship Project

A Web Application used to tranfer credit between multiple users.

Credit is sort of points which can be transferred from one user to another
user.

Flow of the Webste: Home Page > View all Users > Select and View one User >
Transfer Credit > Select user to transfer to >View all Users >View Transfer History.

The project is implemented with the help of HTML, CSS, JavaScript, PHP & Bootstrap.
Project contains basic CRUD operations.

Database contains two Tables(User Table, Transfer Table).
1. User table have basic fields such as name, email, current credit etc. 
2. Transfers table records all transfers happened.
